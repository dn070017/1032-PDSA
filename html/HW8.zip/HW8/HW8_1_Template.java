public class HW8_1{
    
    private static Node root = null;
    
    public static Node BTrebuild(String inString, String postString) {
        // Build a binary tree based on in-order and post-order traversal and return the root of binary tree constructed.
        // The judging system will traverse your binary tree from this root, therefore DO NOT return only the key or value of the root.
        return root;
    }
}